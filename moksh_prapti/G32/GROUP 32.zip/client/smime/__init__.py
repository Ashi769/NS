"""Python S/MIME handler."""

__author__ = 'G. B. Versiani'
__license__ = 'Apache License (2.0)'
__version__ = '0.0.4'

__all__ = [__author__, __license__, __version__]

from .encrypt import encrypt
