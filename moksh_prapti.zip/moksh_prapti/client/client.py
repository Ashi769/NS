import smtplib
import sys
import smime

def sendsmime(from_addr, to_addrs, subject, msg, from_cert, smtpd='localhost'):
	message = [
		'To: "Alice" <'+to_addrs+'>',
		'From: "Bob" <'+from_addr+'>',
		'Subject: '+subject,
		'',
		msg
	]
	
	with open(from_cert, 'rb') as pem:
		msg=smime.encrypt('\n'.join(message), pem.read())
	
	print("to send: ")
	print(msg)

	smtp = smtplib.SMTP()
	smtp.connect(smtpd)
	smtp.sendmail(from_addr, to_addrs, msg)
	smtp.quit()

sendsmime("akhil@mail.com","javed@mail.com",'Sub','this is hidden','./client/signer.pem',smtpd='localhost:1130')
